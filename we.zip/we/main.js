document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.getElementById('searchForm');
    const resultsContainer = document.getElementById('results');
    let map;

    function initMap() {
        map = L.map('map').setView([0, 0], 2);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
    }

    initMap();

    searchForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const city = document.getElementById('cityInput').value;
        
        try {
            const weatherResponse = await fetch(`http://localhost:5050/api/weather/${city}`);
            if (!weatherResponse.ok) throw new Error('City not found');
            
            const data = await weatherResponse.json();
            displayResults(data);
        } catch (error) {
            console.error('Error:', error);
            resultsContainer.innerHTML = '<p class="error">Failed to fetch data</p>';
        }
    });

    function displayResults(data) {
        const { weather, news, countryInfo, exchangeRate } = data;
        const { lat, lon } = weather.coord;
        map.setView([lat, lon], 10);
        L.marker([lat, lon]).addTo(map);

        const weatherHtml = `
            <div class="weather-card">
                <h2>Weather in ${weather.name}</h2>
                <p>Temperature: ${weather.main.temp}°C</p>
            </div>
        `;
        
        const newsHtml = `
            <div class="news-card">
                <h3>Latest News</h3>
                <ul>
                    ${news.map(article => `
                        <li>
                            <a href="${article.url}" target="_blank">${article.title}</a>
                        </li>
                    `).join('')}
                </ul>
            </div>
        `;

        const exchangeRateHtml = `
            <div class="exchange-rate-card">
                <h3>Exchange Rate</h3>
                <p>USD to local currency: ${exchangeRate}</p>
            </div>
        `;

        resultsContainer.innerHTML = weatherHtml + newsHtml + exchangeRateHtml;
    }
});
