const express = require('express');
const axios = require('axios');
const path = require('path');
const cors = require('cors');

const app = express();
const port = 5050;

// API ключи
const WEATHER_API_KEY = "44bc0a9fdbc16051a3511ec3b0cd8353";
const NEWS_API_KEY = "c723b0d938b047b6b4bf3d13a3eece68";

// Middleware
app.use(cors());
app.use(express.static('public'));
app.use(express.json());

// API Routes
app.get('/api/weather/:city', async (req, res) => {
    try {
        const { city } = req.params;

        // Запрос погоды
        const weatherResponse = await axios.get(
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${WEATHER_API_KEY}&units=metric`
        ).catch(() => {
            return res.status(404).json({ error: 'City not found' });
        });

        if (!weatherResponse.data) return;

        // Запрос новостей
        const newsResponse = await axios.get(
            `https://newsapi.org/v2/everything?q=${city}&apiKey=${NEWS_API_KEY}&pageSize=5`
        );

        const countryCode = weatherResponse.data.sys.country;
        // Получение информации о стране
        const factResponse = await axios.get(
            `https://restcountries.com/v3.1/alpha/${countryCode}`
        );

        const currency = Object.keys(factResponse.data[0].currencies)[0];
        // Запрос курса обмена валют
        const exchangeResponse = await axios.get(
            `https://api.exchangerate-api.com/v4/latest/USD`
        ).catch(() => {
            return res.status(500).json({ error: 'Failed to fetch exchange rate' });
        });

        res.json({
            weather: weatherResponse.data,
            news: newsResponse.data.articles,
            countryInfo: factResponse.data[0],
            exchangeRate: exchangeResponse.data.rates[currency]
        });

    } catch (error) {
        console.error('Error:', error.message);
        res.status(500).json({ error: 'Failed to fetch data' });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
